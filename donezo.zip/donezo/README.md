# donezo

Using Flutter, we aim to create a TODO/Task Manager app for individuals and organizations
