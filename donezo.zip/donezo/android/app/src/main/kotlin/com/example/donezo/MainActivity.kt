package com.example.donezo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
